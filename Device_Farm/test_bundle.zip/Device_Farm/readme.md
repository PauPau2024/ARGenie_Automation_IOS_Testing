All the device Farm Files are avaliable here
